<!DOCTYPE html>
<html>
<head>
	<title>Services|Edubod</title>
	<meta charset="utf-8">
		<meta name="viewport" content="width-device-width , initial-scale=1">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
		
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
		<link href="https://fonts.googleapis.com/css?family=Crimson+Text|Inconsolata|K2D|Karla|Krub|Libre+Franklin|Lobster|Merriweather|Niramit|Oswald|Quicksand|Raleway|Roboto|Roboto+Slab|Rubik|Titillium+Web" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
		<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="serv.css">
</head>
<body>
	<div class="edubod">
		<div class="t_bar">
			<img src="images/dialer.png" height="25px" width="15px">
			<h4 id="t_bar_mail">
				<a href="mailto:olabodeogunkeye@yahoo.com?subject=hello%20again" target="_top"><i class="fas fa fa-envelope"></i>olabodeogunkeye@yahoo.com</a>
			</h4>
			<h4 id="t_bar_text">
				+2348109569501
			</h4>
				<a href="register.php">
					<button id="t_bar_reg">
						Register
					</button>
				</a>
				<a href="login.php">
					<button id="t_bar_log">
						Login
					</button>
				</a>
		</div>
		<div class="menu_bar">
			<a href="index.php" style="text-decoration: none; color:#005555 ">
				<h2 style="position: relative; top:25px;left: 20px; font-size: 25px; font-weight: bolder; font-family: serif; ">
					Edubod.edu.org
				</h2>
				<span style="position: relative; top: -25px; left: 200px;">
					<img src="images/book.png" width="50px" height="50px">
				</span>
			</a>
			<span>
				<a href="index.php">
					<button>Home</button>
				</a>
				<a href="services.php">
					<button>Services</button>
				</a>
				<a href="Contact.php">
					<button>Contact</button>
				</a>
				<a href="gallery.php">
					<button>Gallery</button>
				</a>
			</span>
		</div>
		<div class="main-body">
			<div class="col-md-6 left">
				<h1>Our Services <i class="fab fa-servicestack"></i></h1>
				<p>
					<b>Educational Consultations:</b></br>
					In-depth review of student’s educational history.</br>
					Subject Area Tutoring & Study Groups:</br>
					Subject area specialists work with students to support school curriculum to create motivation, build confidence and improve performance.</br>
					<b>College Advisory Service:</b></br>
					Provides a personalized and sensitive approach to college guidance. We help make this journey productive and fulfilling by providing college guidance for students and their parents by giving them the information, tools and skills they need to succeed in the college admission process.</br>
					Standardized Test Prep:</br>
					Area specialists work one-on-one or in small groups providing instruction, strategies and simulated testing environments (SSAT, ISEE, COOP, PSAT, SAT I, SAT II, ACT, AP Exams, GRE).</br>
					<b>Writing Enrichment:</b></br>
					Writing Instructors teach strategies to enhance written expression - geared to the demands of school curriculum and standardized tests.</br>
					<b>Cognitive & Educational Evaluations:</b></br>
					In-depth review of student’s educational history, followed by Intellectual Evaluation and Cognitive-Educational Evaluation.</br>
					<b>Tutorials and Test Prep:</b>
					Programs are designed to address each individual’s academic needs and learning style
				
				</p>
			</div>
			<div class="col-md-6">
				<img src="images/gen5.jpg" width="630px" height="500px">
			</div>
		</div>
		<div class="footer">
			<div class="fsocials" align="center">
				<a href="http://www.facebook.com">
					<i class="fab  fa-facebook fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.twitter.com">
					<i class="fab  fa-twitter fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.instagram.com">
					<i class="fab  fa-instagram fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.gmail.com">
					<i class="fas fa fa-mail-bulk fa-3x"  style="width: 8%;"></i>
				</a>
			</div>
			<h5 align="center">Designed and developed by Olabode Ogunkeye</h5>
			<h5 align="center">Edubod Schools All rights reserved &copy 2018</h5>
		</div>
	</div>
</body>
</html>