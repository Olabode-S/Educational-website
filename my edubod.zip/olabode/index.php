<!DOCTYPE html>
<html>
<head>
	<title>Home|Edubod</title>
		<meta charset="UTF8" >
		<meta name="viewport" content="width-device-width , initial-scale=1">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
	
		<link href="https://fonts.googleapis.com/css?family=Crimson+Text|Inconsolata|K2D|Karla|Krub|Libre+Franklin|Lobster|Merriweather|Niramit|Oswald|Quicksand|Raleway|Roboto|Roboto+Slab|Rubik|Titillium+Web" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
		<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.min.css">	
		<link rel="stylesheet" type="text/css" href="home.css">
</head>
<body>
	<div class="edubod">
		<div class="t_bar">
				<img src="images/dialer.png" height="25px" width="15px">
				<img id="t_bar_mailp" src="images/mail.jpg" height="25px" width="25px">
			<h4 id="t_bar_mail">
				<a href="mailto:olabodeogunkeye@yahoo.com?subject=hello%20again" target="_top">
					olabodeogunkeye@yahoo.com
				</a>
			</h4>

			<h4 id="t_bar_text">
				+2348109569501
			</h4>
				<a href="register.php">
					<button id="t_bar_reg">
						Register
					</button>
				</a>
				<a href="login.php">
					<button id="t_bar_log">
						Login
					</button>
				</a>
		</div>
		<div class="menu_bar">
			<a href="index.php" style="text-decoration: none; color:#006699 ">
				<h2 style="position: relative; top:25px;left: 20px; font-size: 25px; font-weight: bolder; font-family: serif; ">
					Edubod.edu.org
				</h2>
				<span style="position: relative; top: -25px; left: 200px;">
					<img src="images/book.png" width="50px" height="50px">
				</span>
			</a>
			<span>
				<a href="index.php">
					<button>Home</button>
				</a>
				<a href="#about-us">
					<button>About us</button>
				</a>
				<a href="services.php">
					<button>Services</button>
				</a>
				<a href="contact.php">
					<button>Contact</button>
				</a>
				<a href="gallery.php">
					<button>Gallery</button>
				</a>
			</span>
		</div>
		<div align="center" class="main_body">
			<p align="center">WELCOME TO EDUBOD SCHOOLS </br>EDUCATION IS THE KEY TO THE GOLDEN GATE OF THE FUTURE DO NOT MISS OUT ON IT !!! </p>
			<div class="b-loggos" style="font-size: 120px; position: relative;top: 22%;" >
				<i class="fal fa fa-award" style="width: 12%;" ><h3>200</h3></i>
				
				<i class="fal fa fa-book-reader" style="width: 12%;"><h3>80000</h3></i>
				
				<i class="fas fa fa-user-graduate" style="width: 12%;"><h3>250000</h3></i>
				
				<i class="far fa fa-chalkboard-teacher" style="width: 12%;"><h3>150</h3></i>
				
			</div>
		</div>
			
			<div class="arrow">
				<a href="index.php">
				<img src="images/arrow1.png">
				</a>
			</div>	
		<div  class="about-us">
				<a name="about-us">
				<h2 align="center">
						<i class="fas fa fa-bullhorn"></i>
						About Us
				</h2>
				</a>
			<div class="col-md-6 about-img">
				<img src="images/abtp.jpg">
			</div>
			<div id="col-md-6" >
				<p style="font-size: 20px;">
					We believe that everyone has the right to an affordable, quality education.<br>
					As a society, we uphold the notion that it's a good thing <br>
					—the very basis of hope and the key to the promise of upward mobility.<br>
					But brutally high fees and an educational system slow to realize that everyone learns differently have created a paradox. <br>
					Learning should be fun and accessible to everyone, but in many cases, it simply isn't. <br>
					At Edubod.com, we aim to deliver a better way to learn <br>
					— one that lets you learn what you want, the way you want, and in a way you can afford.<br>
					We want to empower you to become that better version of yourself.<br>
					We help over 30 thousand students each year.
				</p>
			</div>
			<div  class="abt-blw">
				<h3 id="tes">Testimonies</h3>
				<h4 id="hef">Here's what a few are saying.........</h4>
				<hr/>
				<blockquote>
					<h4>
						Saved time and money
					</h4>
					<small>
						 I am a mom of 8 and could not afford the time or money that it would take for me to attend college. This gives me a chance to study and take exams that will not only save me money but also shorten the time to finish college.
					</small>
				</blockquote>
				<hr/>
				<blockquote>
					<h4>
						Great study tool
					</h4>
					<small>
						  The Educational  videos were a great study tool. I aced the WAEC exam and earned 5 credits Including english and mathematics!
					</small>
				</blockquote>
				<hr/>
			</div>
		</div>
		<div class="footer">
			<div class="fsocials" align="center">
				<a href="http://www.facebook.com">
					<i class="fab  fa-facebook fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.twitter.com">
					<i class="fab  fa-twitter fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.instagram.com">
					<i class="fab  fa-instagram fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.gmail.com">
					<i class="fas fa fa-mail-bulk fa-3x"  style="width: 8%;"></i>
				</a>
			</div>
			<h5 align="center">Designed and developed by Olabode Ogunkeye</h5>
			<h5 align="center">Edubod Schools All rights reserved &copy 2018</h5>
		</div>
	</div>
</body>
</html>