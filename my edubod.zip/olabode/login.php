<!DOCTYPE html>
<html>
<head>
		<?php
require("connect-db.php");
?>
<?php 
		if (isset($_POST["btnlogin"])){
				$reg=mysql_query("select *from register WHERE (username='".$_POST['username']."' and password='".$_POST['password']."')") or die (mysql_error());
				if (mysql_affected_rows()==1){
					header("location:sucess.php");
				}
				else{
					echo '<script type="javascript">';
					echo 'alert("wrong login details...try again")';
					echo '</script>';
				}
			}
			?>
	<title>Login|Edubod</title>
	<meta name="viewport" content="width-device-width , initial-scale=1">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
	
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
		<link href="https://fonts.googleapis.com/css?family=Crimson+Text|Inconsolata|K2D|Karla|Krub|Libre+Franklin|Lobster|Merriweather|Niramit|Oswald|Quicksand|Raleway|Roboto|Roboto+Slab|Rubik|Titillium+Web" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
		<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="log.css" media="all">
</head>
<body>
 	<form name="elogin" action="" method="POST">
 		<a href="index.php">
	 		<div class="float">
	 			<img src="images/left.png">
	 			<img src="images/left.png">
	 			<img src="images/left.png">
	 			<h4>Back to home page</h4>
	 		</div>
 		</a>
		<div class="login" align="center">
			<h2>Welcome To Edubod Schools Please Login TO Your Account </h2>
			<h3>Dont have an account?</h3>
			<h4>Create one here just click <a href="register.php" style="text-decoration: none;">sign up </a></h4>
			<span id="uselog">
			<h4>Username:<input type="text" name="username" placeholder="Enter your Username" required="yes" minlength="5" maxlength="15"><i class="far fa-user" style="position: relative;left: -20px;"></i>
			<h4>Password:<input type="password" name="password" placeholder="Enter your Password" required="yes" minlength="8" maxlength="10"><i class="fas fa-lock" style="position: relative;left: -20px;"></i>
			
			</h4>
			<input type="submit"  name="btnlogin" value="Login" style="padding: 10px; width: 90px; background: transparent; border-radius: 10px;">
			</span>
		</div>
	</form>
</body>
</html>
