<!DOCTYPE html>
<html>
<head>
	<?php 
		require("connect-db.php");
	?>

	<title>Register|Edubod</title>
	<meta name="viewport" content="width-device-width , initial-scale=1">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<link href="https://fonts.googleapis.com/css?family=Crimson+Text|Inconsolata|K2D|Karla|Krub|Libre+Franklin|Lobster|Merriweather|Niramit|Oswald|Quicksand|Raleway|Roboto|Roboto+Slab|Rubik|Titillium+Web" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
		<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="reg.css" media="all">
</head>
<body>

	<form name="eregister" method="post">
		<a href="index.php" style="text-decoration: none;">
		 		<div class="float">
		 			<img src="images/left.png">
		 			<img src="images/left.png">
		 			<img src="images/left.png">
		 			<h4>Back to home page</h4>
		 		</div>
 		</a>
		<div class="register" align="center">
			<h3>
				Welcome To Edubod Schools Please Create An Account</br>
				Have An Account Already?</br>
				Then Please <a href="login.php" style="text-decoration: none;">Login</a>
			</h3>
			<span id="ireg">
				<table>
					<tr>
						<td align="center">
							<h4>First Name:</h4>
						</td>
						<td align="center">
							<input id="itext" type="text" name="fname" placeholder="Enter  your first name"  required="">
						</td>
					</tr>
					<tr>
						<td align="center">
							<h4>Name:</h4>
						</td>
						<td align="center">
							<input id="itext" type="text" name="name" placeholder="Enter your name" required="">
						</td>
					</tr>
					<tr>
						<td align="center">
							<h4>Username:</h4>
						</td>
						<td align="center">
							<input id="itext" type="text" name="username" placeholder="Enter a username" required="">
						</td>
					</tr>
					<tr>
						<td align="center">
							<h4>Email:</h4>
						</td>
						<td align="center">
							<input id="itext" type="text" name="email" placeholder="Enter your email address" required="">
						</td>
					</tr>
					<tr>
						<td align="center">
							<h4>Password:</h4>
						</td>
						<td align="center">
							<input id="itext" type="password" name="password" placeholder="Enter a password" minlength="8" required="">
						</td>
					</tr>
					<tr>
						<td align="center">
							<h4>Confirm Password</h4>
						</td>
						<td align="center">
							<input id="itext" type="password" name="cpassword" placeholder="Confirm your password" minlength="8" required="">

						</td>
					</tr>
					<tr> 
						<td colspan="2" align="center">
							<input id="btnreg" type="submit" name=" btnreg" value="Register">
							<?php
							if(isset($_POST["btnreg"])){
								$reg=mysql_query("insert into register values ('".$_POST ['fname']."', '".$_POST ['name']."', '".$_POST ['username']."','".$_POST ['email']."', '".$_POST ['password']."')") or die(mysql_error());
								if(mysql_affected_rows()==1){
									echo "Registraion successfull";
										}
									else{
										echo "Registraion  not successfull";
									}
								}
							?>
						</td>
					</tr>
				</table>
			</span>
		</div>
	</form>
</body>
</html>