<!DOCTYPE html>
<html>
<head>
	<title>Login Sucessful</title>
	<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
</head>
<style type="text/css">
	body{
		background-color:black;
	}
	.main-body{
		position: absolute;
		top: 30%;
		left: 30%;
		color: white;
		width: 500px;
		height: 500px;

	}
	.main-body a{
		text-decoration: none;

	}
</style>
<body>
	<div class="main-body" align="center">
		<h1>You have Sucessfully registered to Edubod schools.com The rest of the relevant details would be communicated to you via email
			<a href="index.php">Click here to go back to the home page</a></h1>
	</div>
</body>
</html>