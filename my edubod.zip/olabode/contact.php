<!DOCTYPE html>
<html>
<head>
	<title>Contact|Edubod</title>
	<meta charset="utf-8">
		<meta name="viewport" content="width-device-width , initial-scale=1">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
	
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
		<link href="https://fonts.googleapis.com/css?family=Crimson+Text|Inconsolata|K2D|Karla|Krub|Libre+Franklin|Lobster|Merriweather|Niramit|Oswald|Quicksand|Raleway|Roboto|Roboto+Slab|Rubik|Titillium+Web" rel="stylesheet">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
		<link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="fontawesome/css/font-awesome.min.css" media="all">
		<link rel="stylesheet" type="text/css" href="cont.css">
</head>
<body>
	<div class="edubod">
		<div class="t_bar">
			<img src="images/dialer.png" height="25px" width="15px">
			<h4 id="t_bar_mail">
				<a href="mailto:olabodeogunkeye@yahoo.com?subject=hello%20again" target="_top"><i class="fas fa fa-envelope"></i>olabodeogunkeye@yahoo.com</a>
			</h4>
			<h4 id="t_bar_text">
				+2348109569501
			</h4>
				<a href="register.php">
					<button id="t_bar_reg">
						Register
					</button>
				</a>
				<a href="login.php">
					<button id="t_bar_log">
						Login
					</button>
				</a>
		</div>
		<div class="menu_bar">
			<a href="index.php" style="text-decoration: none; color:#000022 ">
				<h2 style="position: relative; top:25px;left: 20px; font-size: 25px; font-weight: bolder; font-family: serif; ">
					Edubod.edu.org
				</h2>
				<span style="position: relative; top: -25px; left: 200px;">
					<img src="images/book.png" width="50px" height="50px">
				</span>
			</a>
			<span>
				<a href="index.php">
					<button>Home</button>
				</a>
				<a href="services.php">
					<button>Services</button>
				</a>
				<a href="Contact.php">
					<button>Contact</button>
				</a>
				<a href="gallery.php">
					<button>Gallery</button>
				</a>
			</span>
		</div>
		<div class="main-body">
			<div class="body-cont">
				<div class="col-md-6 left">
					<h1>Reach us on Social Media</h1>
					<div class="f-socials">
						<a href="http://www.facebook.com">
							<i class="fab  fa-facebook fa-4x"><h3>Visit our facebook page</h3></i></br>
						</a>
						<a href="http://www.twitter.com">
							<i class="fab  fa-twitter fa-4x"><h3>Visit our twitter page</h3></i></br>
						</a>
						<a href="http://www.instagram.com">
							<i class="fab  fa-instagram fa-4x"><h3>Visit our instagram page</h3></i></br>
						</a>
						<a href="http://www.gmail.com">
							<i class="fas fa fa-mail-bulk fa-4x"><h3>Mail us</h3></i>
						</a>
					</div>
				</div>
				<div class="col-md-6 right">
					<h1>Our Addresses</h1>
					<div>
						<h3>
							Plot 8, Tijufegbe Layout,</br>
							Adio villa, Odo-Ona, Elewe,</br>
							Ibadan,</br>
							Nigeria.
							</br>
							</br>
							No 2, Allen Avenue Ikeja,</br>
							Lagos State,</br>
							Nigeria.</br>
							</br>
							</br>
							Telephone<i class="fas fa fa-phone"></i></br>
							+2348109569501
						</h3>
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.1297897630315!2d3.85422381443359!3d7.339318415178313!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x10398c28c1906447%3A0x4a0f3947a74dd17a!2sAdio+Layout%2C+Oluyole%2C+Ibadan!5e0!3m2!1sen!2sng!4v1540917038106" width="400" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="fsocials" align="center">
				<a href="http://www.facebook.com">
					<i class="fab  fa-facebook fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.twitter.com">
					<i class="fab  fa-twitter fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.instagram.com">
					<i class="fab  fa-instagram fa-3x"  style="width: 8%;"></i>
				</a>
				<a href="http://www.gmail.com">
					<i class="fas fa fa-mail-bulk fa-3x"  style="width: 8%;"></i>
				</a>
			</div>
			<h5 align="center">Designed and developed by Olabode Ogunkeye</h5>
			<h5 align="center">Edubod Schools All rights reserved &copy 2018</h5>
		</div>
	</div>
</body>
</html>