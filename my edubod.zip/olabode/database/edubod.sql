-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2018 at 12:51 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edubod`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `First Name` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`First Name`, `Name`, `Username`, `Email`, `Password`) VALUES
('Ogunkeye', 'olabode', 'olabode40', 'olabodeogunkeye@yahoo.com', 'money only'),
('kayode', 'Segun', 'Segun', 'segun@gmail.com', 'segun1234'),
('Kenneth', 'James', 'james', 'jamesken@yahoo.com', 'james1234'),
('kayode', 'teju', 'tejumade', 'teju@gmail.com', 'tejuteju'),
('olabode', 'ogunkeye', 'exonmobil', 'olabodeogunkeye@yahoo.com', 'qwertyuiop'),
('Ogunkeye', 'olabode', 'mobil', 'olabodeogunkeye@yahoo.com', 'mobilmobil');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
