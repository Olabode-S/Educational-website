open your phpmyadmin
click on import 
locate this folder 
click edubod.sql
