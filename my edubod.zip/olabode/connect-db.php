<?php  
	mysql_connect("localhost", "root", "") or die("server not found");
	mysql_select_db("edubod")or die("database not found");
?>